document.addEventListener("DOMContentLoaded", function(event) { 
    document.getElementById("bootStyle").removeAttribute("disabled");
    document.getElementById("fontStyle").removeAttribute("disabled");
});
