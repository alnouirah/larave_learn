<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CandidateGeneralInfo extends Model
{
    protected $table = 'candidate_general_info';
    protected $guarded = [];
}
