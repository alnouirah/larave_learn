<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CandidateNoamanRelatives extends Model
{
    protected $table = 'candidate_noaman_relativs';
    protected $guarded = [];
}
