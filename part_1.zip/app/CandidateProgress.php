<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CandidateProgress extends Model
{
    //
    protected $table =  'candidate_progress';
    protected $guarded = [];
}
