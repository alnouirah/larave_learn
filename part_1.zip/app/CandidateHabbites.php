<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CandidateHabbites extends Model
{
    protected $table = 'candidate_habbite';
    protected $guarded = [];
}
