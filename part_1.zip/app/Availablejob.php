<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Availablejob extends Model
{
    protected $table = 'available_jobs';
    protected $guarded = [];
}
