<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CandidateNonrelatives extends Model
{
    protected $table = 'candidate_nonrelativs';
    protected $guarded = [];
}
