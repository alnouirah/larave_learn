<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CandidateEducations extends Model
{
    //
    protected $table = 'candidate_education';
    protected $guarded = [];
}
