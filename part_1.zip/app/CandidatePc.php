<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CandidatePc extends Model
{
    protected $table = 'candidate_pc';
    protected $guarded = [];
}
