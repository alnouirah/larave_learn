<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CandidateRelatives extends Model
{
    protected $table = 'candidate_relatives';
    protected $guarded = [];
}
