<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class JobApplications extends Model
{
    protected $table = 'job_applications';
    protected $guarded = [];
}
