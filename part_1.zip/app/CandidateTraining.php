<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CandidateTraining extends Model
{
    protected $table = 'candidate_training';
    protected $guarded = [];
}
