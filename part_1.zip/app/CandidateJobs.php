<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CandidateJobs extends Model
{
    protected $table = 'candidate_jobs';
    protected $guarded = [];
}
