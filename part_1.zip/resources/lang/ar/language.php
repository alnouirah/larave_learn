<?php 

return [
    "personalInfo" => "بيانات أساسية"        ,
    "educations" => "المؤهلات الدراسية"        ,
    "training" => "الدورات التدريبية"        ,
    "experince" => "الخبرات العملية"          ,
    "habbites" => "الهوايات"         ,
    "jobs" => "المهن او الحرف التي تجيدها"           ,
    "langs" => "اللغات"           ,
    "pc" => "مهارات الحاسوب"           ,
    "relatives" => "معرفين أقارب"         ,
    "nonrelatives" => "معرفين غير أقارب"         ,
    "noamanrelatives" => "معرفين من مركز الوظيفة"           ,
    "generalInfo" => "بيانات عامة"          ,
    "applications" => "طلبات التقديم"          ,
];